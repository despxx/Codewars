/*
 8kyu
 Multiply

 This code does not execute properly. Try to figure out wh
 */

func multiply(_ a: Double, _ b: Double) -> Double {
    return a * b
}

print(multiply(-1, 3))
