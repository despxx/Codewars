/*
 8kyu
 You Can't Code Under Pressure #1

 Code as fast as you can! You need to double the integer and return it.
*/

func doubleInteger(_ num: Int) -> Int {
    return num * 2
}
